--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "TheGuild";
--
-- Name: TheGuild; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "TheGuild" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE "TheGuild" OWNER TO postgres;

\connect "TheGuild"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: part2; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA part2;


ALTER SCHEMA part2 OWNER TO postgres;

--
-- Name: SCHEMA part2; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA part2 IS 'Part 2 of QAP2';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: race; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.race (
    race_id integer NOT NULL,
    race character varying(32) NOT NULL,
    description character varying(150) NOT NULL
);


ALTER TABLE part2.race OWNER TO postgres;

--
-- Name: Race_race_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2."Race_race_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2."Race_race_id_seq" OWNER TO postgres;

--
-- Name: Race_race_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2."Race_race_id_seq" OWNED BY part2.race.race_id;


--
-- Name: client; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.client (
    client_id integer NOT NULL,
    status boolean DEFAULT true NOT NULL,
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    organization character varying(32),
    description character varying
);


ALTER TABLE part2.client OWNER TO postgres;

--
-- Name: TABLE client; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.client IS 'Stores info on clients';


--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.client_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.client_client_id_seq OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.client_client_id_seq OWNED BY part2.client.client_id;


--
-- Name: invoiceDetail; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2."invoiceDetail" (
    detail_id integer NOT NULL,
    invoice_num integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE part2."invoiceDetail" OWNER TO postgres;

--
-- Name: TABLE "invoiceDetail"; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2."invoiceDetail" IS 'Contains information on specific invoices';


--
-- Name: invoiceDetail_detail_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2."invoiceDetail_detail_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2."invoiceDetail_detail_id_seq" OWNER TO postgres;

--
-- Name: invoiceDetail_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2."invoiceDetail_detail_id_seq" OWNED BY part2."invoiceDetail".detail_id;


--
-- Name: invoiceMaster; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2."invoiceMaster" (
    invoice_num integer NOT NULL,
    client_id integer NOT NULL,
    invoice_date date DEFAULT now() NOT NULL,
    tax_rate integer,
    special_instructions character varying
);


ALTER TABLE part2."invoiceMaster" OWNER TO postgres;

--
-- Name: TABLE "invoiceMaster"; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2."invoiceMaster" IS 'Invoice clients for product purchases';


--
-- Name: invoiceMaster_invoice_num_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2."invoiceMaster_invoice_num_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2."invoiceMaster_invoice_num_seq" OWNER TO postgres;

--
-- Name: invoiceMaster_invoice_num_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2."invoiceMaster_invoice_num_seq" OWNED BY part2."invoiceMaster".invoice_num;


--
-- Name: invoice_total; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.invoice_total AS
SELECT
    NULL::text AS invoice_number,
    NULL::character varying(32) AS customer,
    NULL::money AS sub_total,
    NULL::money AS tax,
    NULL::money AS total;


ALTER TABLE part2.invoice_total OWNER TO postgres;

--
-- Name: member; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.member (
    member_id integer NOT NULL,
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    title character varying(32),
    rank_id integer,
    join_date date DEFAULT now() NOT NULL,
    race_id integer NOT NULL
);


ALTER TABLE part2.member OWNER TO postgres;

--
-- Name: TABLE member; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.member IS 'Store info on guild members';


--
-- Name: member_member_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.member_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.member_member_id_seq OWNER TO postgres;

--
-- Name: member_member_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.member_member_id_seq OWNED BY part2.member.member_id;


--
-- Name: member_spec; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.member_spec (
    spec_id integer NOT NULL,
    member_id integer NOT NULL,
    last_update date DEFAULT now() NOT NULL
);


ALTER TABLE part2.member_spec OWNER TO postgres;

--
-- Name: TABLE member_spec; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.member_spec IS 'Join table for members & their specializations';


--
-- Name: mission_report; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.mission_report (
    report_id integer NOT NULL,
    mission_num integer NOT NULL,
    member_id integer NOT NULL,
    report_details character varying NOT NULL
);


ALTER TABLE part2.mission_report OWNER TO postgres;

--
-- Name: TABLE mission_report; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.mission_report IS 'Members file missions reports for missions that they have made progress in';


--
-- Name: rank; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.rank (
    rank_id integer NOT NULL,
    rank_name character varying(32) NOT NULL,
    description character varying
);


ALTER TABLE part2.rank OWNER TO postgres;

--
-- Name: TABLE rank; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.rank IS 'Stores info on different guild ranks';


--
-- Name: members_per_rank; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.members_per_rank AS
 SELECT r.rank_name AS rank,
    count(mr.mission_num) AS number_of_members
   FROM ((part2.member m
     JOIN part2.rank r ON ((r.rank_id = m.rank_id)))
     JOIN part2.mission_report mr ON ((mr.member_id = m.member_id)))
  GROUP BY r.rank_name
  ORDER BY (count(mr.mission_num));


ALTER TABLE part2.members_per_rank OWNER TO postgres;

--
-- Name: mission; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.mission (
    mission_num integer NOT NULL,
    job_name character varying(64) NOT NULL,
    job_description character varying NOT NULL,
    payout money NOT NULL,
    creation_date date DEFAULT now() NOT NULL,
    deadline_date date,
    client_id integer
);


ALTER TABLE part2.mission OWNER TO postgres;

--
-- Name: TABLE mission; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.mission IS 'Stores data on missions';


--
-- Name: mission_detail; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.mission_detail (
    mission_detail_id integer NOT NULL,
    mission_num integer NOT NULL,
    product_id integer,
    quantity integer,
    detail_description character varying
);


ALTER TABLE part2.mission_detail OWNER TO postgres;

--
-- Name: TABLE mission_detail; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.mission_detail IS 'Stores repeating details on specific missions';


--
-- Name: mission_detail_mission_detail_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.mission_detail_mission_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.mission_detail_mission_detail_id_seq OWNER TO postgres;

--
-- Name: mission_detail_mission_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.mission_detail_mission_detail_id_seq OWNED BY part2.mission_detail.mission_detail_id;


--
-- Name: mission_income_with_race; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.mission_income_with_race AS
 SELECT (((m.first_name)::text || ' '::text) || (m.last_name)::text) AS member,
    r.race,
    sum(mi.payout) AS total_mission_income
   FROM (((part2.member m
     JOIN part2.race r ON ((r.race_id = m.race_id)))
     JOIN part2.mission_report mr ON ((mr.member_id = m.member_id)))
     JOIN part2.mission mi ON ((mi.mission_num = mr.mission_num)))
  GROUP BY m.first_name, m.last_name, r.race
  ORDER BY (sum(mi.payout)) DESC;


ALTER TABLE part2.mission_income_with_race OWNER TO postgres;

--
-- Name: mission_mission_num_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.mission_mission_num_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.mission_mission_num_seq OWNER TO postgres;

--
-- Name: mission_mission_num_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.mission_mission_num_seq OWNED BY part2.mission.mission_num;


--
-- Name: mission_report_report_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.mission_report_report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.mission_report_report_id_seq OWNER TO postgres;

--
-- Name: mission_report_report_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.mission_report_report_id_seq OWNED BY part2.mission_report.report_id;


--
-- Name: missions_per_member; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.missions_per_member AS
 SELECT (((m.first_name)::text || ' '::text) || (m.last_name)::text) AS member_name,
    count(mr.mission_num) AS count
   FROM (part2.member m
     JOIN part2.mission_report mr ON ((mr.member_id = m.member_id)))
  GROUP BY m.first_name, m.last_name
  ORDER BY (count(mr.mission_num)) DESC;


ALTER TABLE part2.missions_per_member OWNER TO postgres;

--
-- Name: VIEW missions_per_member; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON VIEW part2.missions_per_member IS 'Lets us Track how many missions each member has completed to provide promotions when needed';


--
-- Name: product; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.product (
    product_id integer NOT NULL,
    name character varying(32) NOT NULL,
    cost money NOT NULL,
    description character varying
);


ALTER TABLE part2.product OWNER TO postgres;

--
-- Name: TABLE product; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON TABLE part2.product IS 'Store information on products ';


--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.product_product_id_seq OWNED BY part2.product.product_id;


--
-- Name: product_qty_total_per_item; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.product_qty_total_per_item AS
 SELECT p.name AS product,
    sum(id.quantity) AS quantity_sold,
    sum((id.quantity * p.cost)) AS product_total_sales
   FROM ((part2.product p
     JOIN part2."invoiceDetail" id ON ((id.product_id = p.product_id)))
     JOIN part2."invoiceMaster" im ON ((im.invoice_num = id.invoice_num)))
  GROUP BY p.name, p.cost
  ORDER BY (sum((id.quantity * p.cost))) DESC;


ALTER TABLE part2.product_qty_total_per_item OWNER TO postgres;

--
-- Name: VIEW product_qty_total_per_item; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON VIEW part2.product_qty_total_per_item IS 'This view let us manage our inventory and better set item targets for the guild';


--
-- Name: product_total_per_client; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.product_total_per_client AS
SELECT
    NULL::character varying(32) AS client,
    NULL::character varying(32) AS product,
    NULL::bigint AS quantity_sold,
    NULL::money AS subtotal,
    NULL::money AS tax,
    NULL::money AS total;


ALTER TABLE part2.product_total_per_client OWNER TO postgres;

--
-- Name: rank_rank_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.rank_rank_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.rank_rank_id_seq OWNER TO postgres;

--
-- Name: rank_rank_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.rank_rank_id_seq OWNED BY part2.rank.rank_id;


--
-- Name: specialization; Type: TABLE; Schema: part2; Owner: postgres
--

CREATE TABLE part2.specialization (
    spec_id integer NOT NULL,
    spec_name character varying(32) NOT NULL,
    description character varying
);


ALTER TABLE part2.specialization OWNER TO postgres;

--
-- Name: specialization_spec_id_seq; Type: SEQUENCE; Schema: part2; Owner: postgres
--

CREATE SEQUENCE part2.specialization_spec_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE part2.specialization_spec_id_seq OWNER TO postgres;

--
-- Name: specialization_spec_id_seq; Type: SEQUENCE OWNED BY; Schema: part2; Owner: postgres
--

ALTER SEQUENCE part2.specialization_spec_id_seq OWNED BY part2.specialization.spec_id;


--
-- Name: specs_per_member; Type: VIEW; Schema: part2; Owner: postgres
--

CREATE VIEW part2.specs_per_member AS
 SELECT s.spec_name AS specialization,
    count(ms.spec_id) AS member_per_spec
   FROM ((part2.member m
     JOIN part2.member_spec ms ON ((ms.member_id = m.member_id)))
     JOIN part2.specialization s ON ((s.spec_id = ms.spec_id)))
  GROUP BY ms.spec_id, s.spec_name
  ORDER BY (count(ms.spec_id)) DESC;


ALTER TABLE part2.specs_per_member OWNER TO postgres;

--
-- Name: VIEW specs_per_member; Type: COMMENT; Schema: part2; Owner: postgres
--

COMMENT ON VIEW part2.specs_per_member IS 'This lets us know the number of specs in the guild';


--
-- Name: client client_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.client ALTER COLUMN client_id SET DEFAULT nextval('part2.client_client_id_seq'::regclass);


--
-- Name: invoiceDetail detail_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceDetail" ALTER COLUMN detail_id SET DEFAULT nextval('part2."invoiceDetail_detail_id_seq"'::regclass);


--
-- Name: invoiceMaster invoice_num; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceMaster" ALTER COLUMN invoice_num SET DEFAULT nextval('part2."invoiceMaster_invoice_num_seq"'::regclass);


--
-- Name: member member_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member ALTER COLUMN member_id SET DEFAULT nextval('part2.member_member_id_seq'::regclass);


--
-- Name: mission mission_num; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission ALTER COLUMN mission_num SET DEFAULT nextval('part2.mission_mission_num_seq'::regclass);


--
-- Name: mission_detail mission_detail_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_detail ALTER COLUMN mission_detail_id SET DEFAULT nextval('part2.mission_detail_mission_detail_id_seq'::regclass);


--
-- Name: mission_report report_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_report ALTER COLUMN report_id SET DEFAULT nextval('part2.mission_report_report_id_seq'::regclass);


--
-- Name: product product_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.product ALTER COLUMN product_id SET DEFAULT nextval('part2.product_product_id_seq'::regclass);


--
-- Name: race race_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.race ALTER COLUMN race_id SET DEFAULT nextval('part2."Race_race_id_seq"'::regclass);


--
-- Name: rank rank_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.rank ALTER COLUMN rank_id SET DEFAULT nextval('part2.rank_rank_id_seq'::regclass);


--
-- Name: specialization spec_id; Type: DEFAULT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.specialization ALTER COLUMN spec_id SET DEFAULT nextval('part2.specialization_spec_id_seq'::regclass);


--
-- Data for Name: client; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.client (client_id, status, first_name, last_name, organization, description) FROM stdin;
\.
COPY part2.client (client_id, status, first_name, last_name, organization, description) FROM '$$PATH$$/3711.dat';

--
-- Data for Name: invoiceDetail; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2."invoiceDetail" (detail_id, invoice_num, product_id, quantity) FROM stdin;
\.
COPY part2."invoiceDetail" (detail_id, invoice_num, product_id, quantity) FROM '$$PATH$$/3713.dat';

--
-- Data for Name: invoiceMaster; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2."invoiceMaster" (invoice_num, client_id, invoice_date, tax_rate, special_instructions) FROM stdin;
\.
COPY part2."invoiceMaster" (invoice_num, client_id, invoice_date, tax_rate, special_instructions) FROM '$$PATH$$/3715.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.member (member_id, first_name, last_name, title, rank_id, join_date, race_id) FROM stdin;
\.
COPY part2.member (member_id, first_name, last_name, title, rank_id, join_date, race_id) FROM '$$PATH$$/3717.dat';

--
-- Data for Name: member_spec; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.member_spec (spec_id, member_id, last_update) FROM stdin;
\.
COPY part2.member_spec (spec_id, member_id, last_update) FROM '$$PATH$$/3719.dat';

--
-- Data for Name: mission; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.mission (mission_num, job_name, job_description, payout, creation_date, deadline_date, client_id) FROM stdin;
\.
COPY part2.mission (mission_num, job_name, job_description, payout, creation_date, deadline_date, client_id) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: mission_detail; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.mission_detail (mission_detail_id, mission_num, product_id, quantity, detail_description) FROM stdin;
\.
COPY part2.mission_detail (mission_detail_id, mission_num, product_id, quantity, detail_description) FROM '$$PATH$$/3721.dat';

--
-- Data for Name: mission_report; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.mission_report (report_id, mission_num, member_id, report_details) FROM stdin;
\.
COPY part2.mission_report (report_id, mission_num, member_id, report_details) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.product (product_id, name, cost, description) FROM stdin;
\.
COPY part2.product (product_id, name, cost, description) FROM '$$PATH$$/3726.dat';

--
-- Data for Name: race; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.race (race_id, race, description) FROM stdin;
\.
COPY part2.race (race_id, race, description) FROM '$$PATH$$/3733.dat';

--
-- Data for Name: rank; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.rank (rank_id, rank_name, description) FROM stdin;
\.
COPY part2.rank (rank_id, rank_name, description) FROM '$$PATH$$/3728.dat';

--
-- Data for Name: specialization; Type: TABLE DATA; Schema: part2; Owner: postgres
--

COPY part2.specialization (spec_id, spec_name, description) FROM stdin;
\.
COPY part2.specialization (spec_id, spec_name, description) FROM '$$PATH$$/3730.dat';

--
-- Name: Race_race_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2."Race_race_id_seq"', 10, true);


--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.client_client_id_seq', 14, true);


--
-- Name: invoiceDetail_detail_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2."invoiceDetail_detail_id_seq"', 86, true);


--
-- Name: invoiceMaster_invoice_num_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2."invoiceMaster_invoice_num_seq"', 19, true);


--
-- Name: member_member_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.member_member_id_seq', 26, true);


--
-- Name: mission_detail_mission_detail_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.mission_detail_mission_detail_id_seq', 1, false);


--
-- Name: mission_mission_num_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.mission_mission_num_seq', 40, true);


--
-- Name: mission_report_report_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.mission_report_report_id_seq', 39, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.product_product_id_seq', 31, true);


--
-- Name: rank_rank_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.rank_rank_id_seq', 4, true);


--
-- Name: specialization_spec_id_seq; Type: SEQUENCE SET; Schema: part2; Owner: postgres
--

SELECT pg_catalog.setval('part2.specialization_spec_id_seq', 15, true);


--
-- Name: race Race_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.race
    ADD CONSTRAINT "Race_pkey" PRIMARY KEY (race_id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- Name: invoiceDetail invoiceDetail_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceDetail"
    ADD CONSTRAINT "invoiceDetail_pkey" PRIMARY KEY (detail_id);


--
-- Name: invoiceMaster invoiceMaster_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceMaster"
    ADD CONSTRAINT "invoiceMaster_pkey" PRIMARY KEY (invoice_num);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (member_id);


--
-- Name: member_spec member_spec_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member_spec
    ADD CONSTRAINT member_spec_pkey PRIMARY KEY (spec_id, member_id);


--
-- Name: mission_detail mission_detail_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_detail
    ADD CONSTRAINT mission_detail_pkey PRIMARY KEY (mission_detail_id);


--
-- Name: mission mission_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission
    ADD CONSTRAINT mission_pkey PRIMARY KEY (mission_num);


--
-- Name: mission_report mission_report_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_report
    ADD CONSTRAINT mission_report_pkey PRIMARY KEY (report_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: rank rank_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.rank
    ADD CONSTRAINT rank_pkey PRIMARY KEY (rank_id);


--
-- Name: specialization specialization_pkey; Type: CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.specialization
    ADD CONSTRAINT specialization_pkey PRIMARY KEY (spec_id);


--
-- Name: invoice_total _RETURN; Type: RULE; Schema: part2; Owner: postgres
--

CREATE OR REPLACE VIEW part2.invoice_total AS
 SELECT ((im.invoice_num || ''::text) || im.client_id) AS invoice_number,
    c.organization AS customer,
    sum((p.cost * id.quantity)) AS sub_total,
    (sum(((p.cost * id.quantity) * im.tax_rate)) / 100) AS tax,
    ((sum(((p.cost * id.quantity) * im.tax_rate)) / 100) + sum((p.cost * id.quantity))) AS total
   FROM (((part2."invoiceMaster" im
     JOIN part2."invoiceDetail" id ON ((id.invoice_num = im.invoice_num)))
     JOIN part2.product p ON ((p.product_id = id.product_id)))
     JOIN part2.client c ON ((c.client_id = im.client_id)))
  GROUP BY im.invoice_num, c.organization;


--
-- Name: product_total_per_client _RETURN; Type: RULE; Schema: part2; Owner: postgres
--

CREATE OR REPLACE VIEW part2.product_total_per_client AS
 SELECT c.organization AS client,
    p.name AS product,
    sum(id.quantity) AS quantity_sold,
    (p.cost * id.quantity) AS subtotal,
    (((p.cost * id.quantity) * im.tax_rate) / 100) AS tax,
    ((((p.cost * id.quantity) * im.tax_rate) / 100) + (p.cost * id.quantity)) AS total
   FROM (((part2.product p
     JOIN part2."invoiceDetail" id ON ((id.product_id = p.product_id)))
     JOIN part2."invoiceMaster" im ON ((im.invoice_num = id.invoice_num)))
     JOIN part2.client c ON ((c.client_id = im.client_id)))
  GROUP BY c.organization, p.product_id, id.quantity, im.tax_rate
  ORDER BY ((((p.cost * id.quantity) * im.tax_rate) / 100) + (p.cost * id.quantity)) DESC;


--
-- Name: mission client; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission
    ADD CONSTRAINT client FOREIGN KEY (client_id) REFERENCES part2.client(client_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoiceMaster client; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceMaster"
    ADD CONSTRAINT client FOREIGN KEY (client_id) REFERENCES part2.client(client_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoiceDetail invoice; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceDetail"
    ADD CONSTRAINT invoice FOREIGN KEY (invoice_num) REFERENCES part2."invoiceMaster"(invoice_num) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: member_spec member; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member_spec
    ADD CONSTRAINT member FOREIGN KEY (member_id) REFERENCES part2.member(member_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: mission_report member; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_report
    ADD CONSTRAINT member FOREIGN KEY (member_id) REFERENCES part2.member(member_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: mission_report mission; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_report
    ADD CONSTRAINT mission FOREIGN KEY (mission_num) REFERENCES part2.mission(mission_num) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: mission_detail mission_num; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_detail
    ADD CONSTRAINT mission_num FOREIGN KEY (mission_num) REFERENCES part2.mission(mission_num) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoiceDetail product; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2."invoiceDetail"
    ADD CONSTRAINT product FOREIGN KEY (product_id) REFERENCES part2.product(product_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: mission_detail product_id; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.mission_detail
    ADD CONSTRAINT product_id FOREIGN KEY (product_id) REFERENCES part2.product(product_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: member race_fk; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member
    ADD CONSTRAINT race_fk FOREIGN KEY (race_id) REFERENCES part2.race(race_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: member rank; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member
    ADD CONSTRAINT rank FOREIGN KEY (rank_id) REFERENCES part2.rank(rank_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: member_spec specialization; Type: FK CONSTRAINT; Schema: part2; Owner: postgres
--

ALTER TABLE ONLY part2.member_spec
    ADD CONSTRAINT specialization FOREIGN KEY (spec_id) REFERENCES part2.specialization(spec_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

