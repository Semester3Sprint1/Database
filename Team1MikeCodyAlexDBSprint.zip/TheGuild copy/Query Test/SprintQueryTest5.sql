SELECT * FROM part2.members_per_rank
Where rank = 'Diamond';